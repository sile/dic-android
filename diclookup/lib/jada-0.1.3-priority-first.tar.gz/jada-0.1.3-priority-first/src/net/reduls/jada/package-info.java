/**
 * DoubleArray Trie実装のメインパッケージ
 */
package net.reduls.jada;